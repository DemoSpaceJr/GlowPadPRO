async function setColor(color) {
  try {
    await fetch(`https://your-webapi-address.com/setColor?rgb=${color.replace('#','')}`);
    console.log("Color set to:", color);
  } catch (err) {
    console.error("API Error:", err);
  }
}