function switchController(type) {
  const img = document.getElementById("controller");
  img.style.opacity = 0;
  setTimeout(() => {
    img.src = type + ".png";
    img.style.opacity = 1;
  }, 300);
}

function setMode(mode) {
  if (mode === "rainbow") {
    document.body.style.animation = "gradientMove 3s linear infinite";
  }
}